// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyCuRwaP5FCcbUXMSsum9k7gh0hPamANOpc",
  authDomain: "affialte-programing.firebaseapp.com",
  databaseURL: "https://affialte-programing-default-rtdb.firebaseio.com",
  projectId: "affialte-programing",
  storageBucket: "affialte-programing.firebasestorage.app",
  messagingSenderId: "1076409926581",
  appId: "1:1076409926581:web:eb4861d0bcd641c5f2cffc",
  measurementId: "G-94P4D6LGX5"
};